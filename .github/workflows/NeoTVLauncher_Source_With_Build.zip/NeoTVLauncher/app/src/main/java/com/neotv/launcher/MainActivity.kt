package com.neotv.launcher

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.KeyEvent
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val bg = Color.rgb(16, 19, 27)
    private val panel = Color.rgb(28, 33, 45)
    private val mint = Color.rgb(112, 225, 193)
    private val white = Color.WHITE

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        render()
    }

    private fun rounded(color: Int, radius: Float = 22f): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = radius }

    private fun label(text: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER_VERTICAL
        }

    private fun render() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(42, 28, 42, 24)
            setBackgroundColor(bg)
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val brand = label("NEO  /  TV", 27f, mint, true)
        header.addView(brand, LinearLayout.LayoutParams(0, 60, 1f))
        val date = SimpleDateFormat("EEE  •  HH:mm", Locale.getDefault()).format(Date())
        header.addView(label(date, 17f, Color.LTGRAY))
        root.addView(header)

        val welcome = label("كل ترفيهك، في مكان واحد", 29f, white, true)
        val welcomeParams = LinearLayout.LayoutParams(-1, 70)
        welcomeParams.topMargin = 10
        root.addView(welcome, welcomeParams)
        root.addView(label("تطبيقاتك", 19f, mint, true))

        val scroll = ScrollView(this)
        val grid = GridLayout(this).apply { columnCount = 5; setPadding(0, 14, 0, 12) }
        scroll.addView(grid)
        val params = LinearLayout.LayoutParams(-1, 0, 1f)
        params.topMargin = 4
        root.addView(scroll, params)

        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
        val activities = pm.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != packageName }
            .distinctBy { it.activityInfo.packageName }
            .sortedBy { it.loadLabel(pm).toString().lowercase(Locale.getDefault()) }

        if (activities.isEmpty()) {
            val empty = label("ما لقيناش تطبيقات تلفزيونية قابلة للعرض.", 18f, white)
            root.addView(empty)
        } else {
            activities.forEachIndexed { index, info ->
                val tile = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER
                    background = rounded(panel)
                    isFocusable = true
                    isFocusableInTouchMode = true
                    setPadding(12, 12, 12, 12)
                    setOnFocusChangeListener { v, hasFocus ->
                        v.background = rounded(if (hasFocus) Color.rgb(47, 65, 75) else panel)
                        v.scaleX = if (hasFocus) 1.05f else 1f
                        v.scaleY = if (hasFocus) 1.05f else 1f
                    }
                    setOnClickListener {
                        val launch = pm.getLaunchIntentForPackage(info.activityInfo.packageName)
                        if (launch != null) startActivity(launch)
                    }
                }
                val icon = ImageView(this).apply {
                    setImageDrawable(info.loadIcon(pm))
                    scaleType = ImageView.ScaleType.FIT_CENTER
                }
                tile.addView(icon, LinearLayout.LayoutParams(68, 68))
                val name = label(info.loadLabel(pm).toString(), 14f, white, true).apply {
                    gravity = Gravity.CENTER
                    maxLines = 2
                    ellipsize = android.text.TextUtils.TruncateAt.END
                }
                val nameParams = LinearLayout.LayoutParams(-1, 46)
                nameParams.topMargin = 8
                tile.addView(name, nameParams)
                val tileParams = GridLayout.LayoutParams().apply {
                    width = 0
                    height = 142
                    columnSpec = GridLayout.spec(index % 5, 1f)
                    setMargins(7, 7, 7, 7)
                }
                grid.addView(tile, tileParams)
            }
        }

        val footer = label("HOME  •  التطبيقات المثبتة على جهازك", 13f, Color.GRAY)
        val footParams = LinearLayout.LayoutParams(-1, 35)
        root.addView(footer, footParams)
        setContentView(root)
        grid.getChildAt(0)?.requestFocus()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_MENU) {
            render()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }
}
